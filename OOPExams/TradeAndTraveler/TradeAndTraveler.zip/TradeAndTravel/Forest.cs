﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradeAndTravel
{
    public class Forest:GatheringLocation
    {
        public Forest(string locationName):base(locationName,LocationType.Forest,ItemType.Wood,ItemType.Weapon)
        {
        }

        public override Item ProduceItem(string itemName)
        {
            return new Wood(itemName, null);
        }
    }
}
